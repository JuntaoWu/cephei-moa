#import <UIKit/UIKit.h>
#import <CoreData/CoreData.h>
#import "WxApi.h"
#import "UserInfo.h"

@interface AppDelegate : UIResponder <UIApplicationDelegate, WXApiDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
