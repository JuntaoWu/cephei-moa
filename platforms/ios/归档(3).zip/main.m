//
//  main.m
//  ios-template
//
//  Created by lijian on 15/01/2018.
//  Copyright © 2018 egret. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
